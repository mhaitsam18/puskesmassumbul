<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('Profile_m');

	}

	public function index()
	{
		$data['dataprofile']	= $this->Profile_m->get_info();
		$data['content'] = 'profile_v';
		$this->load->view('template_v', $data, FALSE);
		
	}
}

/* End of file Profile.php */
/* Location: ./application/controllers/Profile.php */