<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kontak extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

	}

	public function index()
	{
		$data['content'] = 'kontak_v';

		$this->load->view('template_v', $data, FALSE);
		
	}

}

/* End of file Kontak.php */
/* Location: ./application/controllers/Kontak.php */