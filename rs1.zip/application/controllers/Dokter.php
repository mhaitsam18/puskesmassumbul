<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dokter extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Dokter_m');
	}

	function index()
	{
		$data['dokter']  = $this->Dokter_m->getAll();
		$jddoc   		 = $this->Dokter_m->getJadwal();

		if($jddoc){
			foreach ($jddoc as $r) {
				$d_id   = $r['d_id'];
				$d_hari = $r['d_hari'];
				$data['jadwal']["$d_id"]["$d_hari"] = $r['d_jam'].'@@'.$r['d_desc'];
			}
		}


		$data['content'] = 'dokter_v';
		$this->load->view('template_v', $data);
	}

	function detail($permalink)
	{
		$data['dokter']  = $this->Dokter_m->getLayByPermalink($permalink)->row_array();
		$data['content'] = "dokter_detail_v";
		$this->load->view('template_v', $data);
	}
}

/* End of file Dokter.php */
/* Location: ./application/controllers/Dokter.php */