<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['google_client_id']="441815597816-5uaj5sq2dhidlbqjcgh21tc34ecftske.apps.googleusercontent.com";
$config['google_client_secret']="BI4lkxfG-WCyZt7oKbklQjGw";
$config['google_redirect_url']=base_url().'login/google';

