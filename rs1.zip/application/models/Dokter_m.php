<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dokter_m extends CI_Model {

    private $table_name     = "tb_dokter";
    private $primary_key    = "d_id";


    function getAll() {
        $this->db->select('a.*, b.poli_nama');
        $this->db->join('tb_poli b', 'a.d_poli = b.poli_kode', 'left');
        $this->db->order_by('b.poli_nama', 'asc');
        $this->db->order_by('a.d_fullname', 'asc');
        $query = $this->db->get($this->table_name.' a');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    function getJadwal() {
        $this->db->select('a.d_id, b.d_hari, b.d_jam, b.d_desc');
        $this->db->join('tb_jadwal_dokter b', 'a.d_id = b.d_id', 'left');
        $this->db->order_by('a.d_id', 'asc');
        $this->db->order_by('b.d_hari', 'asc');
        $query = $this->db->get($this->table_name.' a');
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
    }

    function getLayByPermalink($permalink) {
        $this->db->where('permalink', $permalink);
        $this->db->order_by($this->primary_key, 'desc');
        
        return $this->db->get($this->table_name, 1);
        if ($query->num_rows() == 1) {
            return $query->row_array();
        }
    }

}

/* End of file Dokter_m.php */
/* Location: ./application/models/server/Dokter_m.php */