<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_m extends CI_Model {


	function get_banner() {
		$this->db->where('c_name', 'banner');
		$dbanner = $this->db->get('tb_identitas')->row_array();
		return $dbanner['c_value'];
	}

	function get_slider() {
		$this->db->order_by('slid_id', 'asc');
		$query = $this->db->get('tb_slider');
		if ($query->num_rows() > 0) {
			return $query->result_array();
		}
	}

	function get_recentnews() {
		$this->db->where('c_flag', 1);
		$this->db->order_by('c_id', 'desc');
		$query = $this->db->get('tb_news', 5);
		if ($query->num_rows() > 0) {
			return $query->result_array();
		}
	}

}

/* End of file Home_m.php */
/* Location: ./application/models/Home_m.php */