<link href="<?php echo base_url() ?>assets/plugins/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/adminlte.min.css">
<!-- CONTENT -->
<div id="page-content">
  <div class="section section_team">
    <div class="container">
      <div class="row row-title ">
        <div class="col s12">
          <div class="section-title row-title-team">
            <span class="theme-secondary-color">DAFTAR</span> DOKTER
          </div>
        </div>
      </div>
      <?php
          if ($dokter): 
              $out = '';
              $no = 0;
              foreach ($dokter as $rs):
                $out .= '<div class="box box-info">
                          <div class="table-responsive">
                            <div class="box-header">
                              <h3 class="box-title">'.++$no.'. '.$rs['d_fullname'].'</h3>
                              <br>
                              <span style="margin-left:20px;">'.$rs['poli_nama'].'</span>
                            </div>
                            <div class="box-body no-padding">
                              <table class="table table-bordered table-striped">
                                <tr>
                                  <th class="text-center">HARI</th>
                                  <th class="text-center">JADWAL</th>
                                </tr>';

                                $did = $rs['d_id'];
                                if(isset($jadwal[$did])){
                                  foreach ($jadwal[$did] as $hari => $value) {
                                    $val = explode('@@', $value);
                                    $out .= '<tr>
                                              <td nowrap>'.strtoupper(cekhari($hari)).'</td>
                                              <td class="text-center" nowrap>'.$val[0].'</td>
                                             </tr>';
                                  }
                                }
                                  
                      $out .= '</table>
                            </div>
                          </div>
                        </div>';
              endforeach;
              echo $out;
          endif;
      ?>
    </div>
  </div>
</div>