<!-- CONTENT -->
<div id="page-content">
  <div class="container">
    <div class="row">
      <div class="col s12">
        <br>
        <p class="text-justify">
           <?=$dataprofile?>
        </p>
        <br>
      </div>
    </div>
  </div>
</div>
<!-- END CONTENT -->
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>