<!-- CONTENT -->
<div id="page-content">
  <div class="container">
    <div class="row">
      <div class="col s12">
       <div class="news-content">
        <br>
            <div class="news-detail">
              <h5 class="news-title"><a href="#"><?php echo $news['c_title']; ?></a></h5>
              <div class="date">
                <span><i class="fa fa-calendar"></i> <?php echo date('d F Y', strtotime($news['created_on'])); ?></span>
                <br><br>
              </div>
              <img src="<?php echo base_url()?>image/news/<?php echo $news['c_image']; ?>" alt="image-news">
              <p>
                 <?php echo $news['c_desc']; ?>
              </p> 
            </div>
          </div>
      </div>
    </div>
   <div class="row">
     <div class="col s12">
     </div>
   </div>
  </div>
</div>
<!-- END CONTENT -->


<!-- NEWS -->
<div class="section list-news">
  <div class="container">
    <div class="row row-title">
      <div class="col s12">
        <div class="section-title">
          <span class="theme-secondary-color">BERITA</span> TERBARU
        </div>
      </div>
    </div>
    <div class="row row-list-news">
      <div class="col s12">
        <?php 
          if ($recentnews): 
              foreach ($recentnews as $rnews):
                echo '<div class="news-item">
                        <div class="news-tem-image">
                          <img src="'.base_url().'image/news/'.$rnews['c_image'].'">
                        </div>
                        <div class="news-item-info">
                          <div class="list-news-title">
                            '.$rnews['c_title'].'
                          </div>
                          '.$rnews['c_intro'].'
                          <a href="'.base_url().'news/detail/'.$rnews['permalink'].'" class="readmore"><i class="fa fa-edit"></i> Selengkapnya</a>
                        </div>
                      </div>';
              endforeach;
          endif;
        ?>
        <div class="more-news-list">
          <a href="<?php echo base_url()?>news" class="readmore">Lainnya >></a>
        </div>
      </div>
    </div>
  </div>
</div>